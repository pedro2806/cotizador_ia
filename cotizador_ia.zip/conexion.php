<?php
/**
 * CONFIGURACIÓN GLOBAL DEL COTIZADOR MESS a
 */

// 1. Configuración de la Base de Datos
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "cotizador_ia";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Asegurar que soporte tildes y eñes
$conn->set_charset("utf8mb4");

?>